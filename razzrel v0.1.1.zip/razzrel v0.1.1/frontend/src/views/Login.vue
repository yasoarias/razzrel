<template>
  <div>
    <LoginForm />
  </div>
</template>

<script>
import LoginForm from "@/components/LoginForm.vue";

export default {
  name: "LoginView", // Change to a multi-word name
  components: {
    LoginForm,
  },
};
</script>
