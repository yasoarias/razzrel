<template>
  <div class="home-container">
    <div class="home-card">
      <h1>Welcome to Razzrel Events</h1>
      <p>Timeless Events, Celebrate with Style.</p>
      <router-link to="/login" class="btn primary">Get Started</router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomePage",
};
</script>

<style scoped>
.home-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(120deg, #84fab0, #8fd3f4);
}

.home-card {
  background: white;
  padding: 3rem;
  border-radius: 15px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  text-align: center;
  max-width: 500px;
}

h1 {
  margin-bottom: 1rem;
  color: #333;
}

p {
  margin-bottom: 2rem;
  color: #666;
  font-size: 1.2rem;
}

.btn {
  padding: 0.75rem 1.5rem;
  text-decoration: none;
  font-size: 1rem;
  border-radius: 5px;
  font-weight: bold;
}

.btn.primary {
  background-color: #2196f3;
  color: white;
  border: none;
}

.btn.primary:hover {
  background-color: #1976d2;
}
</style>

