<!-- RegisterForm.vue -->
<template>
  <div>
    <h2>Create Your Account</h2>
    <form @submit.prevent="register">
      <div class="input-group">
        <label for="name">Name</label>
        <input v-model="name" type="text" id="name" required />
      </div>
      <div class="input-group">
        <label for="email">Email</label>
        <input v-model="email" type="email" id="email" required />
      </div>
      <div class="input-group">
        <label for="contactNumber">Contact Number</label>
        <input v-model="contactNumber" type="text" id="contactNumber" required />
      </div>
      <div class="input-group">
        <label for="password">Password</label>
        <input v-model="password" type="password" id="password" required />
      </div>
      <button type="submit" class="register-btn">Register</button>
      <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
    </form>
    <button @click="$emit('close')" class="close-btn">X</button>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: "RegisterForm",
  data() {
    return {
      name: '',
      email: '',
      contactNumber: '',
      password: '',
      errorMessage: '',
    };
  },
  methods: {
    async register() {
      try {
        await axios.post('http://localhost:5000/api/auth/register', {
          name: this.name,
          email: this.email,
          contactNumber: this.contactNumber,
          password: this.password,
        });
        this.$emit('close');
        this.$router.push('/login');
      } catch (error) {
        this.errorMessage = 'Registration failed. Please try again.';
      }
    },
  },
};
</script>

<style scoped>
/* Styles for the registration form */
.input-group {
  margin-bottom: 1rem;
  text-align: left;
}

label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: bold;
}

input {
  width: 100%;
  padding: 0.5rem;
  border-radius: 5px;
  border: 1px solid #ccc;
}

.register-btn {
  margin-top: 1.5rem;
  padding: 0.75rem;
  background-color: #42b72a;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
}

.close-btn {
  position: absolute;
  top: 10px;
  right: 10px;
  background: none;
  border: none;
  font-size: 1.25rem;
  cursor: pointer;
}

/* Error message styling */
.error-message {
  color: #e57373;
  margin-top: 1rem;
}
</style>
