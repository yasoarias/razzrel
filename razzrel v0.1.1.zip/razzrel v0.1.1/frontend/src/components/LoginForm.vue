<template>
  <div class="login-container">
    <div class="login-card">
      <h2>Login</h2>
      <form @submit.prevent="login">
        <div class="input-group">
          <input type="email" placeholder="Email" v-model="email" required />
        </div>
        <div class="input-group">
          <input type="password" placeholder="Password" v-model="password" required />
        </div>
        <button type="submit" class="login-btn">Log In</button>
      </form>
      <a href="#" class="forgot-password">Forgot password?</a>
      <hr />
      <button @click="showModal = true" class="create-account-btn">Create new account</button>
    </div>

    <!-- Registration Modal -->
    <div v-if="showModal" class="modal-overlay" @click.self="closeModal">
      <div class="modal-content">
        <RegisterForm @close="closeModal" />
      </div>
    </div>
  </div>
</template>

<script>
import RegisterForm from './RegisterForm.vue';

export default {
  data() {
    return {
      email: '',
      password: '',
      showModal: false,
    };
  },
  methods: {
    login() {
      // Handle login logic here
    },
    closeModal() {
      this.showModal = false;
    },
  },
  components: {
    RegisterForm,
  },
};
</script>

<style scoped>
/* Styling for the login container and modal */
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f0f2f5;
}

.login-card {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  width: 400px;
  text-align: center;
}

.input-group {
  margin-bottom: 1.5rem;
}

input {
  width: 100%;
  padding: 0.75rem;
  border-radius: 5px;
  border: 1px solid #ddd;
}

.login-btn {
  width: 100%;
  padding: 0.75rem;
  background-color: #1877f2;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1rem;
  cursor: pointer;
}

.create-account-btn {
  width: 100%;
  padding: 0.75rem;
  background-color: #42b72a;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1rem;
  cursor: pointer;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  width: 500px;
  position: relative;
}
</style>
