module.exports = {
    jwtSecret: process.env.JWT_SECRET || 'de99f2f1-c725-495e-93c3-a42a0982e70d',
  };
  